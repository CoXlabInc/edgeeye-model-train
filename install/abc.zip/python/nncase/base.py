import os
import sys

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import _nncase
